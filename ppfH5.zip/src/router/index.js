import Vue from 'vue'
import Router from 'vue-router'
import Storage from '@/util/storage'
import HelloWorld from '@/components/HelloWorld'
/* home */
import Home from '@/components/home/home'
import Acticity from '@/components/home/activity'
import Test from '@/components/home/test'
import SubActicity from '@/components/home/subActivity'
import SelectVenue from '@/components/home/selectVenue'
import SelectArea from '@/components/home/selectArea'
import SelectSeat from '@/components/home/selectSeat'
/* order */
import OrderDetail from '@/components/order/orderDetail'
import OrderList from '@/components/order/orderList'
/* mine */
import Mine from '@/components/mine/mine'
import Collection from '@/components/mine/collection'
import Share from '@/components/mine/share'
import Setting from '@/components/mine/setting'
/* login */
import Login from '@/components/login/login'
import Register from '@/components/login/register'
import ForgetPass from '@/components/login/forgetPass'

Vue.use(Router);

let storage = new Storage();

const router = new Router({
  routes: [
    // {
    //   path: '/',
    //   name: 'HelloWorld',
    //   component: HelloWorld
    // },
    {
      path: '/',
      name: 'Home',
      component: Home,
      children: [
        {
          path: '/',
          name: 'Test',
          component: Test,
        },
        {
          path: '/orderList',
          name: 'OrderList',
          component: OrderList,
        },
        {
          path: '/mine',
          name: 'Mine',
          component: Mine,
        },
      ]
    },
    {
      path: '/selectSeat',
      name: SelectSeat,
      component: SelectSeat
    },
    {
      path: '/selectArea',
      name: SelectArea,
      component: SelectArea
    },
    {
      path: '/selectVenue',
      name: SelectVenue,
      component: SelectVenue
    },
    {
      path: '/test',
      name: HelloWorld,
      component: HelloWorld
    },
    {
      path: '/subActivity',
      name: SubActicity,
      component: SubActicity
    }
  ]
});

router.beforeEach((to, from, next) => {
  console.log('bigname', '------router跳转-----');
  console.log('bigname', to, from);
  let tag = '&token=';
  let tokenIndex = to.fullPath.indexOf(tag);
  /* 如果带有token */
  if (tokenIndex > -1) {
    console.log('bigname', '------带token的router跳转-----');
    /* 去掉token后的跳转路径 */
    let pathWithOutToken = to.fullPath.substr(0, tokenIndex);
    let token = window.atob(to.fullPath.substr(tokenIndex + tag.length, to.fullPath.length));
    console.log('bigname', to.fullPath, token);
    /* 将token保存到缓存 */
    storage.setToken(token);
    next(
      {
        replace: true,
        path: pathWithOutToken
      }
    );
  }
  next();
});

export default router;
