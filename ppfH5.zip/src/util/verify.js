/**
 * createBy: LiangSJ
 * date: 2019-1-10 15:00
 * desc: ??? 数据缓存工具类
 *
 */

class Verify {
  constructor() {
  }

  isNull(obj) {
    if (obj == null) {
      return true;
    }
    return false;
  };

  isNullOrZero(str) {
    if (this.isNull(str)) {
      return true;
    }else {
      if (str.length <= 0) {
        return true;
      }
      return false;
    }
  }

  isNullOrZeroOrUndefined (str) {
    if (this.isNullOrZero(str)) {
      return true;
    }else {
      if (typeof str == 'undefined') {
        return true;
      }
      return false;
    }
  }

  isNullOrZeroOrUndefineds (arr) {
    for (let str of arr) {
      if(this.isNullOrZeroOrUndefined(str)) {
        return true;
      }
    }
    return false;
  }



}


/**
 * 暴露
 */
export default Verify
