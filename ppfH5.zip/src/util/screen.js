
/**
 * createBy: LiangSJ
 * date: 2019-1-10 15:00
 * desc: ??? 数据缓存工具类
 * 
*/

class Screen {

  screenHeight = 0;


  constructor() {
    this.screenHeight = document.documentElement.clientHeight;
  }

  /* 获取屏幕高度 */
  getScreenHeight () {
    return this.screenHeight;
  }

  /* 获取header高度 */
  getHeaderHeight (headerEl) {
    if (headerEl) {
      return headerEl.clientHeight;
    }
    return 0;
  };

  /* 获取内容高度 */
  getContainerHeight (headerEl,containerEl) {
    return this.screenHeight - headerEl ? headerEl.clientHeight : 0 - containerEl ? containerEl.clientHeight : 0;
  }

}



/**
 * 暴露
*/
export default Screen
