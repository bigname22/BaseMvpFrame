
/**
 * createBy: LiangSJ
 * date: 2019-1-10 15:00
 * desc: ??? 数据缓存工具类
 * 
*/

class StorageService {
  constructor() { }

  STORAGE_KEYS = {
    IWX_TOKEN: 'IWX_TOKEN',                              // token
  };


  /**
   * 核心get/set  如果需要改变get/set的实现方式只需要改动这一层
  */
  getSync = function (key) {
    return sessionStorage.getItem(key);
  };
  setSync = function (key, value) {
    return sessionStorage.setItem(key, value);
  };

  /**
   * CODE -=> 微信登录code
  */
  getToken = function () {
    return this.getSync(this.STORAGE_KEYS.IWX_TOKEN);
  };

  setToken = function (value) {
    return this.setSync(this.STORAGE_KEYS.IWX_TOKEN, value);
  };


}



/**
 * 暴露
*/
export default StorageService
