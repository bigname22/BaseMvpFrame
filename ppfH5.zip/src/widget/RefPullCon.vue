<template>
  <div class="container">
    <div v-show="isShowTopLoading">
      {{topLoadingText}}
    </div>
    <div v-show="isShowBottomLoading">
      {{bottomLoadingText}}
    </div>
  </div>
</template>
<style scoped>

</style>
<script>

  export default {
    name: 'RefRullCon',
    data(){
      return {
        isShowTopLoading:false,
        isShowBottomLoading: false,
        topLoadingText: '上:加载中...',
        bottomLoadingText: '下:加载中...',
      }
    },
    methods: {


    },
    mounted(){

    }
  }
</script>
