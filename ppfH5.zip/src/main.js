// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import Vconsole from 'vconsole';
import '../global.css'
let VueTouch = require('vue-touch');
import MintUI from 'mint-ui'
import 'mint-ui/lib/style.css'

// import MuseUI from 'muse-ui';
// import 'muse-ui/dist/muse-ui.css';

const vConsole = new Vconsole();
export default vConsole;

Vue.use(MintUI);
// Vue.use(MuseUI);
Vue.use(VueTouch, {name: 'v-touch'});

Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>',
});
