class Constant {
  constructor () {}

  /* 公开模式，开发：false；发布：true */
  PRODUCT = false;

  // appKey
  APP_KEY = '10000';

  // url
  URL = {
    TEST_URL : {
      LOGIN_URL: 'http://aaa.iierp.com' + '/iSSO' + "/index.html#/?pagePk=" + 'a9956be8-934a-451c-9d86-de221053cf57' + '&url=' + 'http://10.0.0.22:8081/#/',
      // LOGIN_URL: 'http://localhost:9090/#/' + '?pagePk=' + 'a9956be8-934a-451c-9d86-de221053cf57' + '&url=' + 'http://localhost:8080/#/',
      // BASE_URL: 'https://w3.iierp.com/ywx1/api',
      // BASE_URL: 'http://hmtusr50.iierp.com:9097',
      BASE_URL: 'http://aaa.iierp.com/iwx1',
    },
    URL : {
      LOGIN_URL: '',
      BASE_URL: 'https://w3.iierp.com/ywx1/api',
    }
  };

  // page pk
  PAGE_PK = {
    TEST_PAGE_PK : 'd0b102b9-1967-4a59-85c0-78f2af419125', // aaa || 8011 oliver
    // PAGE_PK = '0617447a-3ea7-4beb-96ea-755d7e1776f8'; //w3 new

    // PAGE_PK = '1b494e20-ac27-4153-9e3e-72231a14da26';    // w3
    // PAGE_PK = '0617447a-3ea7-4beb-96ea-755d7e1776f8'; //w3 new
    PAGE_PK : 'aec0d80c-1190-4be1-8650-19cf1810fca1', //w3 xinjiang
  };

  // --------------------对外提供方法--------------------

  /* 获取pagePk */
  getPagePk () {
    if(this.PRODUCT) {
      return this.PAGE_PK.PAGE_PK;
    }
    return this.PAGE_PK.TEST_PAGE_PK;
  };

  /* 获取app key */
  getAppKey () {
    return this.APP_KEY;
  };

  /* 获取login url */
  getLoginUrl () {
    if(this.PRODUCT) {
      return this.URL.URL.LOGIN_URL;
    }
    return this.URL.TEST_URL.LOGIN_URL;
  };

  /* 获取base url */
  getBaseUrl () {
    if(this.PRODUCT) {
      return this.URL.URL.BASE_URL;
    }
    return this.URL.TEST_URL.BASE_URL;
  };



}

export default Constant
