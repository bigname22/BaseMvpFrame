<template>
    
</template>

<script>
    export default {
        name: "collection"
    }
</script>

<style scoped>

</style>
