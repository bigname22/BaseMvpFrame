<template>
    
</template>

<script>
    export default {
        name: "share"
    }
</script>

<style scoped>

</style>
