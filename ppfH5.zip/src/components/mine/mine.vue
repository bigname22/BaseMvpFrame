<template>
    <div>mine</div>
</template>

<script>
    export default {
        name: "mine"
    }
</script>

<style scoped>

</style>
