<template>
    
</template>

<script>
    export default {
        name: "setting"
    }
</script>

<style scoped>

</style>
