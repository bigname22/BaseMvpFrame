<template>
  <div>
    <mt-button class="mt-lg" @click="btnClickTest">登录</mt-button>
    <mt-tab-container class="page-tabbar-container" v-model="selected">
      <router-view></router-view>
    </mt-tab-container>

    <mt-tabbar v-model="selected" fixed style="display: none">
      <mt-tab-item id="home">
        <img slot="icon" src="../../assets/icons/ic_home.svg">
        首页
      </mt-tab-item>
      <mt-tab-item id="order">
        <img slot="icon" src="../../assets/icons/ic_order.svg">
        订单
      </mt-tab-item>
      <mt-tab-item id="mine">
        <img slot="icon" src="../../assets/icons/ic_mine.svg">
        我的
      </mt-tab-item>
    </mt-tabbar>
  </div>

</template>

<script>
  import Constant from "../../constant/constant";
  const constant = new Constant();
  export default {
    name: "home",
    data() {
      return {
        selected: 'home',
      }
    },
    methods: {
      btnClickTest () {
        let needLogin = true;
        if(needLogin) {
          needLogin = false;
          let loginUrl = constant.getLoginUrl();
          console.log('bigname', location.href);
          window.location.replace(loginUrl);
        }
      },
    },
    created () {
      console.log("home page created-----------");
    },
    watch: {
      selected: function (val, oldVal) {
        // 这里就可以通过 val 的值变更来确定去向
        switch (val) {
          case 'home':
            this.$router.push('/');
            break;
          case 'order':
            this.$router.push('/orderList');
            break;
          case 'mine':
            this.$router.push('/mine');
            break;
        }
      }
    }
  }
</script>

<style scoped>

</style>
