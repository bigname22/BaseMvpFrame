<template>
  <div style="width: 100%;overflow:scroll">
    <mt-header fixed title="活动列表"></mt-header>
    <!--activity-->
    <!--<mt-button @click="btnClickSelectSeat">选座</mt-button>-->
    <!--<mt-button @click="btnClickPostActivities">请求活动列表</mt-button>-->
      <div v-for="(item, index) in activityList" class="item-box card" style="position: relative"
           @click="btnClickItem(item)">
        <!-- 顶部小功能栏 -->
        <div class="item-function flex row reverse items-center">
          <img @click.stop="btnClickCollect(item)"
               :src="item.isFav?require('../../assets/icons/ic_collect.svg'):require('../../assets/icons/ic_uncollect.svg')"
               class="iv-sm mr-sm">
        </div>
        <!-- 海报 -->
        <img v-if="item.logoPath" :src="item.logoPath" class="iv-poster">
        <!-- 显示内容 -->
        <div class="item-content flex justify-center text-white items-center">
          <div class="text-bold text-md">
            {{item.eventName}}
          </div>
        </div>
      </div>

  </div>
</template>

<script>
  import Fetch from '../../http/fetch'
  import Storage from '../../util/storage'
  import Constant from '../../constant/constant'

  let fetch = new Fetch();
  let storage = new Storage();
  let constant = new Constant();
  export default {
    name: "home",
    data() {
      return {
        page: 0,
        pageSize: 4,
        startDate: '',
        endDate: '',
        searchText: '',
        activityList: [1],
        finishLoad: false,
      }
    },
    created() {
      this.postActivityList(this.pageSize, this.page, this.searchText, this.startDate, this.endDate);
    },
    methods: {
      // 请求活动列表
      postActivityList(pageSize, page, searchText, startDate, endDate) {
        fetch.getEventList(constant.getPagePk(), pageSize, page, searchText, startDate, endDate).then(
          res => {
            console.log('res:', res);
            if (res.status == 200) {
              if (res.data.StatusCode == 200) {
                this.activityList = res.data.Data;
                this.finishLoad = true;
                this.$refs.loadmore.onTopLoaded();
                this.$refs.loadmore.onBottomLoaded();
              }
            }
            setTimeout(()=>{
              this.$refs.loadmore.onBottomLoaded();
            },1000);
          }
        ).catch(
          err => {
            console.log('err:', err);
          }
        );
      },
      // 添加收藏
      postAddCollect(item) {
        let type = 'EV0101_EVT_MSTR';
        let name = item.eventName;
        let url = `/pages/index/eventDetail/index?eventId=${item.eventId}`;
        fetch.addToFav(item.eventId, type, name, url).then(
          res => {
            console.log("res成功", res);
            item.isFav = true;
          }
        ).catch(
          err => {
            console.log("err失败", err);
          }
        )
      },
      postRemoveCollect(item) {
        fetch.removeFav(item.favId).then(
          res => {
            console.log("res成功", res);
            item.isFav = false;
          }
        ).catch(
          err => {
            console.log("err失败", err);
          }
        )
      },
      btnClickSelectSeat() {
        this.$router.push('SelectSeat');
      },
      btnClickPostActivities() {
        fetch.getShareOrderList(20, 0).then(res => {
          console.log('請求成功', res);
        }).catch(err => {
          console.log('請求失敗', err);
        });
      },
      btnClickCollect(item) {
        if (item.isFav) {
          this.postRemoveCollect(item);
        } else {
          this.postAddCollect(item);
        }
      },
      btnClickItem(item) {
        this.$router.push({
          path: '/subActivity',
          query: {activityId: item.eventId},
        });
      },
    },

  }
</script>

<style scoped>
  .item-box {
    width: 94%;
    margin-left: 3%;
    margin-top: 16px;
    height: 208px !important;
  }

  .iv-poster {
    width: 100%;
    height: 208px;
    position: absolute;
    top: 0;
  }

  .item-function {
    width: 100%;
    height: 28px;
    z-index: 1000;
    position: absolute;
    top: 0;
  }

  .item-content {
    width: 100%;
    height: 68px;
    z-index: 999;
    position: absolute;
    bottom: 0;
    background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.31));
  }
</style>
