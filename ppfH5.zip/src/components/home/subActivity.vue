<template>
  <div>
    <mt-header ref="header" fixed title="环节列表"></mt-header>
    <div  :style="{marginTop: headerHeight+'px'}">
      <!-- 头信息 活动 -->
      <transition name="slide-fade">
        <div v-if="isShowTopInfo" class="bg-low pa-sm">
          {{datas.eventName}}
        </div>
      </transition>
      <!-- 环节列表 -->
      <div   @scroll.stop="listScroll" style="overflow: scroll" :style="{height: contentHeight+'px'}">
        <div v-for="(item, index) in datas.funcList" class="flex pa-md"
             style="border-bottom: 1px solid rgba(204,204,204,0.16)">
          <!-- 左 -->
          <div style="flex: 5;position: relative" class="iv-box">
            <img :src="item.logo" class="iv-poster">
            <!-- 顶部小功能栏 -->
            <div class="item-function flex items-center">
              <img @click.stop="btnClickCollect(item)"
                   :src="item.isFav?require('../../assets/icons/ic_collect.svg'):require('../../assets/icons/ic_uncollect.svg')"
                   class="iv-sm mr-sm">
            </div>
          </div>
          <!-- 右 -->
          <div style="flex: 5" class="flex column pa-xs justify-between">
            <!-- 内容 -->
            <div class="text-xs text-faded flex justify-between items-center no-wrap">
              <div>
                <!-- 环节名称 -->
                <div class="text-bold text-md text-black mb-sm">{{item.funcName}}</div>
                <!-- 开始时间 -->
                <div class="flex items-center no-wrap">
                  <img src="../../assets/icons/ic_start.svg" class="iv-xxs">
                  <div class="text-ellipsis">{{item.startTime}}</div>
                </div>
                <!-- 结束时间 -->
                <div class="flex items-center mt-xs no-wrap">
                  <img src="../../assets/icons/ic_end.svg" class="iv-xxs">
                  <div class="text-ellipsis">{{item.endTime}}</div>
                </div>
              </div>
              <div>
                <img src="../../assets/icons/ic_right.svg" class="iv-md">
              </div>


            </div>
            <!-- 按钮 -->
            <div class="flex row reverse pt-xs">
              <div class="btn-buy" @click="btnClickBuy(item)">购票</div>
            </div>

          </div>
        </div>
      </div>


      <!--<div v-for="item in 7">-->
      <!--{{item}}-->
      <!--</div>-->
    </div>

  </div>
</template>

<script>

  import Verify from '../../util/verify';
  import Fetch from '../../http/fetch';
  import Screen from '../../util/screen';

  let verify = new Verify();
  let fetch = new Fetch();
  let screen = new Screen();

  export default {
    name: "subActivity",
    data() {
      return {
        activityId: '',
        headerHeight: 0,
        contentHeight: 0,
        isShowTopInfo: true,
        lastScrollTop: 0,
        datas: {
          funcList: []
        },
      }
    },
    created() {
      this.activityId = this.$route.query.activityId;
      this.postSubActivity(this.activityId);
    },
    mounted () {
      console.log('header', this.$refs['header'].$el);
      console.log('header height: ------', screen.getHeaderHeight(this.$refs['header'].$el));
      this.headerHeight = screen.getHeaderHeight(this.$refs['header'].$el);
      this.contentHeight = screen.getContainerHeight(this.$refs['header'].$el)
    },
    methods: {
      // 请求子活动列表
      postSubActivity(actId) {
        if (verify.isNullOrZeroOrUndefined(actId)) {
          console.log('-------verify不通过');
          return;
        }
        fetch.getFuncList(actId).then(res => {
          if (res.status == 200) {
            if (res.data.StatusCode == 200) {
              this.datas = res.data.Data;
              console.log('---', this.datas);
            }
          }
        }).catch(err => {

        });
      },
      // 添加收藏
      postAddCollect(item) {
        let type = 'EV0101_EVT_MSTR';
        let name = item.eventName;
        let url = `/pages/index/eventDetail/index?eventId=${item.eventId}`;
        fetch.addToFav(item.eventId, type, name, url).then(
          res => {
            console.log("res成功", res);
            item.isFav = true;
          }
        ).catch(
          err => {
            console.log("err失败", err);
          }
        )
      },
      postRemoveCollect(item) {
        fetch.removeFav(item.favId).then(
          res => {
            console.log("res成功", res);
            item.isFav = false;
          }
        ).catch(
          err => {
            console.log("err失败", err);
          }
        )
      },
      btnClickBuy(item) {
        this.$router.push(
          {
            path: '/selectVenue',
            query: {
              subActivityId: item.funcId
            }
          }
        );
      },
      listScroll (e) {
        // console.log('scroll:', e.target.scrollTop);
        // 上拉
        if (e.target.scrollTop > this.lastScrollTop) {
          console.log('上啦');
          this.isShowTopInfo = false;
        }else {
          this.isShowTopInfo = true;
        }
        this.lastScrollTop = e.target.scrollTop;
      },
      btnClickCollect(item) {
        if (item.isFav) {
          this.postRemoveCollect(item);
        } else {
          this.postAddCollect(item);
        }
      },
    }
  }
</script>

<style scoped>
  .iv-poster {
    max-width: 100%;
    max-height: 228px;
    border-radius: 6px;
  }

  .iv-box {
    /*background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.31));*/
  }

  .btn-buy {
    font-size: 12px;
    padding: 4px 22px;
    border-radius: 12px;
    border: 1px solid #ff0835;
    color: #ff0835;
  }

  .item-function {
    width: 100%;
    height: 28px;
    z-index: 1000;
    position: absolute;
    top: 0;
    padding: 1px 3px;
  }

  /* 可以设置不同的进入和离开动画 */
  /* 设置持续时间和动画函数 */
  .slide-fade-enter-active {
    transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
  }

  .slide-fade-leave-active {
    transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
  }

  .slide-fade-enter
    /* .slide-fade-leave-active for below version 2.1.8 */
  {
    transform: translateY(-10px);
    opacity: 0;
  }
  .slide-fade-leave-to {
    transform: translateY(-10px);
    opacity: 0;
  }

</style>
