<template>
  <div class="hello">
    <mt-header fixed title="选择座位"></mt-header><mt-header ref="head" fixed title="选择区域"></mt-header>
    <!-- 信息栏 -->
    <div ref="info" style="margin-top: 48px" class="flex justify-between items-center pa-sm">
      <div class="flex column text-faded">
        <div class="text-md text-bold text-black mb-xs">{{datas.eventName}}</div>
        <div class="text-sm mb-xs">{{datas.funcName}}-{{areaName}}</div>
        <div class="text-xs mb-xs">{{datas.space}}</div>
        <div class="flex items-center">
          <img src="../../assets/icons/ic_start.svg" class="iv-xs">
          <div>{{datas.funcStartTime}}</div>
          <img src="../../assets/icons/ic_end.svg" class="iv-xs">
          <div>{{datas.funcEndTime}}</div>
        </div>
      </div>
      <div>
        <img src="../../assets/icons/ic_right.svg" class="iv-md">
      </div>
    </div>
    <!-- 选座 -->
    <v-touch
      class="ca"
      ref="panel"
      v-on:pinch="pinch"
      v-on:pinchstart="pinchStart"
      v-on:swipeleft="onSwipeLeft"
      v-on:pan="pan"
      v-on:panstart="panStart"
      v-on:tap="tap"
      style=""
    >
      <div
        style="overflow: hidden"
        :style="{width: boundaryInfo.boxWidth+'px',height: boundaryInfo.boxHeight+'px',transform:'translate(' + boundaryInfo.tranX + 'px,' + boundaryInfo.tranY + 'px) ' + 'scale('+boundaryInfo.panelScale+','+boundaryInfo.panelScale+')'}"
        ref="seat-box"
      >
        <!--<div ref="seat-container" style="background: darkgoldenrod;"></div>-->
        <div ref="seat-container" style="background: darkgoldenrod;position: absolute;"
             :style="{width: boundaryInfo.containerWidth + 'px',height: boundaryInfo.containerHeight + 'px',top: boundaryInfo.containerTop+'px',left: boundaryInfo.containerLeft + 'px'}">
          <!-- alt=“是为了去掉当没有src时，会默认出现的小图片” -->
          <img alt="" v-for="(item,index) in datas.boothList"
               :src="item.ShapeType !=='EV5040_03'?'':require('../../assets/icons/'+status2Img[item.BoothStsId])"
               style="position: absolute"
               :style="{top: item.Y+'px',left: item.X+'px',width: item.X_Length+'px',height: item.Y_Length+'px',background:item.ShapeType ==='EV5040_03'?'none':item.BackgroundColor,
                zIndex: item.ShapeType === 'EV5040_03'?999:1}"
               @click="btnClickItem(item,index)">
        </div>

        <!--<div class="child"></div>-->
      </div>
    </v-touch>
  </div>
</template>

<script>
  import getData from "../mock"
  import Verify from '../../util/verify';
  import Fetch from '../../http/fetch';

  let verify = new Verify();
  let fetch = new Fetch();
  let mock = new getData();
  export default {
    name: 'HelloWorld',
    data() {
      return {
        seats: [],
        msg: 'Welcome to Your Vue.js App',
        subActivityId: '',
        venueId: '',
        areaId: '',
        areaName: '',
        hand: 'none',
        count: 0,
        datas: {},
        boundaryInfo: {
          xMin: 0,     // x坐标最小值
          xMax: 0,     // x坐标最大值
          yMin: 0,     // y坐标最小值
          yMax: 0,     // y坐标最大值
          xDiff: 0,    // x坐标差  xMax - xMin
          yDiff: 0,    // y坐标差  yMax - yMin
          xDiffWoXL: 0,// x坐标差  xMax - xMin 不算上X_Length
          yDiffWoYL: 0,    // y坐标差  yMax - yMin
          xMaxCount: 0,// x轴上最多数量
          yMaxCount: 0,// y轴上最多数量
          xScale: 1,   // 坐标与屏幕的缩放比例   windowWidth / xDiff
          yScale: 1,   // 坐标与屏幕的缩放比例   windowHeight / yDiff
          xScaleWoXL: 1,
          yScaleWoYL: 1,
          scale: 1,
          scaleWoLen: 1,// 不算上XYLength
          seatWidth: 20,// 座位宽度
          windowWidth: 0,// 屏幕宽
          windowHeight: 0,// 屏幕高
          boxWidth: 0,   // 容器宽
          boxHeight: 0,  // 容器高
          xRightLen: 0,  //x轴上最后一个座位宽度
          yRightLen: 0,  //y轴上最后一个座位高度
          xMaxLen: 0,  //x轴最大座位宽度
          yMaxLen: 0,  //y轴最大座位高度
          panelScale: 1,
          lastPanelScale: 1,
          tranX: 0,
          tranY: 0,
          lastTranX: 0,
          lastTranY: 0,
          containerTop: 0,
          containerLeft: 0,
          containerWidth: 0,
          containerHeight: 0,
        },
        status2Img: {
          //item.statusId == "EV5006_A" ? "/img/seat.png" : item.statusId == "checked" ? "/img/selectseat.png" : "/img/noseat.png
          "EV5006_A": "ic_seat_white.png",
          "checked": "ic_seat_green.png",
          "EV5006_M": "ic_seat_red.png",
        }
      }
    },
    created() {
      // console.log(getData());
      this.subActivityId = this.$route.query.subActivityId;
      this.venueId = this.$route.query.venueId;
      this.areaId = this.$route.query.areaId;
      this.areaName = this.$route.query.areaName;
      this.postSeats(this.subActivityId, this.venueId, this.areaId);
    },
    mounted() {
      // this.insertElement(this.createElement(42, 12,'你',1),this.$refs['seat-box']);
      // this.seats = this.seats.map(item => {
      //   return {
      //     X: item.X,
      //     Y: item.Y
      //   }
      // });
      /* 实现思路
       * 步骤一：把整个座位图去掉多余的边界距离，即没有padding
       * 步骤二：利用绝对定位把座位按原本的位置描绘出来
       * 步骤三：进行缩放适应屏幕
        * */

    },
    methods: {
      postSeats(subActId, venueId, areaId) {
        if (verify.isNullOrZeroOrUndefineds([subActId, venueId, areaId])) {
          console.log('参数为空');
          return;
        }
        fetch.getAreaBoothChart(subActId, venueId, areaId).then(
          res => {
            if (res.status == 200) {
              if (res.data.StatusCode == 200) {
                this.datas = res.data.Data;
                this.countMaxAndMin(this.datas.boothList);
                this.changeSeat(this.datas.boothList);
                this.dealSeat(this.datas.boothList);
              }
            }
          }
        ).catch(
          err => {

          }
        )
      },
      /* 计算x,y最大、最小值；x、y的length最大值 */
      countMaxAndMin(seats) {
        // x最大值
        this.boundaryInfo.xMax = seats.reduce((a, b) => {
          return b.X > a.X ? b : a;
        }).X;
        // x最小值
        this.boundaryInfo.xMin = seats.reduce((a, b) => {
          return b.X > a.X ? a : b;
        }).X;
        // y最大值
        this.boundaryInfo.yMax = seats.reduce((a, b) => {
          return b.Y > a.Y ? b : a;
        }).Y;
        // y最小值
        this.boundaryInfo.yMin = seats.reduce((a, b) => {
          return b.Y > a.Y ? a : b;
        }).Y;
        // X_length最大值
        this.boundaryInfo.xMaxLen = seats.reduce((a, b) => {
          return b.X_Length > a.X_Length ? b : a;
        }).X_Length;
        // Y_Length最大值
        this.boundaryInfo.yMaxLen = seats.reduce((a, b) => {
          return b.Y_Length > a.Y_Length ? b : a;
        }).Y_Length;
        // x轴最后一个宽度
        this.boundaryInfo.xRightLen = seats.reduce((a, b) => {
          return b.X > a.X ? b : a;
        }).X_Length;
        // y轴最后一个高度
        this.boundaryInfo.yRightLen = seats.reduce((a, b) => {
          return b.Y > a.Y ? b : a;
        }).Y_Length;
      },
      changeSeat() {
        // 改变值
        this.boundaryInfo.xDiff = this.boundaryInfo.xMax - this.boundaryInfo.xMin + this.boundaryInfo.xRightLen;
        this.boundaryInfo.yDiff = this.boundaryInfo.yMax - this.boundaryInfo.yMin + this.boundaryInfo.yRightLen;
        this.boundaryInfo.xDiffWoXL = this.boundaryInfo.xMax - this.boundaryInfo.xMin;
        this.boundaryInfo.yDiffWoYL = this.boundaryInfo.yMax - this.boundaryInfo.yMin;
        let windowWidth = document.documentElement.clientWidth;
        let windowHeight = document.documentElement.clientHeight;
        this.boundaryInfo.windowWidth = windowWidth;
        this.boundaryInfo.windowHeight = windowHeight;
        // let boxHeight = this.$refs['seat-box'].offsetHeight;
        // let boxWidth = this.$refs['seat-box'].offsetWidth;
        let boxWidth = windowWidth;
        // let t = this.$refs['head'].offsetHeight;
        // let tt = this.$refs['info'].offsetHeight;
        let boxHeight = windowHeight - 48 - this.$refs['info'].offsetHeight;
        this.boundaryInfo.boxWidth = boxWidth;
        this.boundaryInfo.boxHeight = boxHeight;
        // seat length会出现大于整个区域宽高xDiff yDiff的情况，所以...
        this.boundaryInfo.xDiff = Math.max(this.boundaryInfo.xMaxLen, this.boundaryInfo.xDiff);
        this.boundaryInfo.yDiff = Math.max(this.boundaryInfo.yMaxLen, this.boundaryInfo.yDiff);
        this.boundaryInfo.xDiffWoXL = Math.max(this.boundaryInfo.xRightLen, this.boundaryInfo.xDiffWoXL);
        this.boundaryInfo.yDiffWoYL = Math.max(this.boundaryInfo.yRightLen, this.boundaryInfo.yDiffWoYL);
        this.boundaryInfo.xScale = boxWidth / this.boundaryInfo.xDiff;
        this.boundaryInfo.yScale = boxHeight / this.boundaryInfo.yDiff;
        this.boundaryInfo.xScaleWoXL = boxWidth / this.boundaryInfo.xDiffWoXL;
        this.boundaryInfo.yScaleWoYL = boxHeight / this.boundaryInfo.yDiffWoYL;
        this.boundaryInfo.scale = Math.min(this.boundaryInfo.xScale, this.boundaryInfo.yScale);
        this.boundaryInfo.scaleWoLen = Math.min(this.boundaryInfo.xScaleWoXL, this.boundaryInfo.yScaleWoYL);

      },
      dealSeat(seats) {
        // --------------------处理逻辑
        seats.map((item) => {
          item.X -= this.boundaryInfo.xMin;
          item.X *= this.boundaryInfo.scale;
          item.Y -= this.boundaryInfo.yMin;
          item.Y *= this.boundaryInfo.scale;
          item.X_Length = item.X_Length * this.boundaryInfo.scale;
          item.Y_Length = item.Y_Length * this.boundaryInfo.scale;
          return item;
        });
        this.boundaryInfo.containerWidth = this.boundaryInfo.xDiff * this.boundaryInfo.scale;
        this.boundaryInfo.containerHeight = this.boundaryInfo.yDiff * this.boundaryInfo.scale;
        this.boundaryInfo.containerLeft = (this.boundaryInfo.boxWidth - this.boundaryInfo.containerWidth) / 2;
        this.boundaryInfo.containerTop = (this.boundaryInfo.boxHeight - this.boundaryInfo.containerHeight) / 2;
      },
      createElement(item, str, id) {
        let seatEl = document.createElement("img");
        seatEl.innerHTML = str;
        // seatEl.id = id;
        let cssText = `position: absolute;top: ${item.Y}px;left: ${item.X}px;width: ${item.X_Length}px;height: ${item.Y_Length}px;`;
        // "EV5006_A"是座位
        if (item.ShapeType === "EV5040_03") {
          cssText += `z-index:9999`;
          seatEl.src = require(`../../assets/icons/${this.status2Img[item.BoothStsId]}`);
          seatEl.onclick = e => {
            console.log('--------------------');
            e.target.src = require(`../../assets/icons/${this.status2Img.checked}`); //require(this.status2Img["checked"])
            return false;
          };
        } else {
          cssText += `background: ${item.BackgroundColor}`;
        }
        seatEl.style.cssText = cssText;

        return seatEl;
      },
      insertElement(element, parent) {
        parent.appendChild(element);
      },
      btnClickItem(item, index) {
        if (item.ShapeType === "EV5040_03") {
          switch (item.BoothStsId) {
            case 'checked':
              item.BoothStsId = 'EV5006_A';
              break;
            case 'EV5006_A':
              item.BoothStsId = 'checked';
              break;
            case 'EV5006_M':
              break;
          }
          console.log(this.seats);
          // item.img = require(`../assets/icon/${this.status2Img[item.BoothStsId]}`);
        }
        return false;
      },
      pinch(e) {
        this.hand = '缩放' + this.count++;
        console.log('缩放', e.scale);
        console.log('缩放', this.$refs.panel.$el.style);
        this.boundaryInfo.panelScale = (e.scale - 1) + this.boundaryInfo.lastPanelScale;
        // this.$refs.panel.$el.style.WebkitTransform = "scale("+ e.scale +")";
        // this.$refs.panel.$el.style.MozTransform = "scale("+ e.scale +")";
        // this.$refs.panel.$el.style.msTransform = "scale("+ e.scale +")";
        // this.$refs.panel.$el.style.OTransform = "scale("+ e.scale +")";
        // this.$refs.panel.$el.style.transform = "scale("+ e.scale +")";
      },
      pinchStart(e) {
        this.boundaryInfo.lastPanelScale = this.boundaryInfo.panelScale;
      },
      onSwipeLeft(e) {
        this.hand = '左滑' + this.count++;
      },
      pan(e) {
        this.hand = 'pan' + this.count++;
        this.boundaryInfo.tranX = e.deltaX + this.boundaryInfo.lastTranX;
        this.boundaryInfo.tranY = e.deltaY + this.boundaryInfo.lastTranY;
      },
      panStart(e) {
        this.boundaryInfo.lastTranX = this.boundaryInfo.tranX;
        this.boundaryInfo.lastTranY = this.boundaryInfo.tranY;
      },
      tap(e) {
        this.hand = 'tap' + this.count++;
      },
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
  .ca {
    /*transform: translate(0px, 0px) scale(0.5,0.5);*/
    overflow: hidden;
  }

  .child {
    position: absolute;
    top: 42px;
    left: 12px;
    background: red;
    width: 20px;
    height: 20px;
  }

  .vc-switch {
    top: 78px !important;
    bottom: unset !important;
    right: unset !important;
    left: 0 !important;
  }
</style>
