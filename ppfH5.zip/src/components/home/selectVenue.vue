<template>
  <div>
    <mt-header fixed title="选择场馆"></mt-header>
    <!-- 信息栏 -->
    <div style="margin-top: 48px" class="flex justify-between items-center pa-sm">
      <div class="flex column text-faded">
        <div class="text-md text-bold text-black mb-xs">{{datas.eventName}}</div>
        <div class="text-sm mb-xs">{{datas.funcName}}</div>
        <div class="text-xs mb-xs">{{datas.space}}</div>
        <div class="flex items-center">
          <img src="../../assets/icons/ic_start.svg" class="iv-xs">
          <div>{{datas.funcStartTime}}</div>
          <img src="../../assets/icons/ic_end.svg" class="iv-xs">
          <div>{{datas.funcEndTime}}</div>
        </div>
      </div>
      <div>
        <img src="../../assets/icons/ic_right.svg" class="iv-md">
      </div>

    </div>
    <!-- 场馆列表 -->
    <div class="flex flex-wrap items-center justify-center">
      <span v-for="(item, index) in datas.areaList" @click="btnClickVenue(item)" class="btn-venue text-white bg-primary pa-sm ma-md">
        {{item.name}}
      </span>
    </div>

    <img :src="datas.areaList && datas.areaList.length>0?datas.areaList[0].logo: ''" class="iv-vence">
  </div>
</template>

<script>
  import Verify from '../../util/verify';
  import Fetch from '../../http/fetch';

  let verify = new Verify();
  let fetch = new Fetch();
  export default {
    name: "selectArea",
    data() {
      return {
        subActivityId: '',
        datas: {},
      }
    },
    created() {
      this.subActivityId = this.$route.query.subActivityId;
      this.postAreaList(this.subActivityId);
    },
    methods: {
      postAreaList(subActId) {
        if (verify.isNullOrZeroOrUndefined(subActId)) {
          console.log('subActId is null');
          return;
        }
        fetch.getSectionList(subActId).then(
          res => {
            if (res.status == 200) {
              if (res.data.StatusCode == 200) {
                this.datas = res.data.Data;
                console.log('---', this.datas);
              }
            }
          }
        ).catch(
          err => {

          }
        );
      },
      btnClickVenue (item) {
        this.$router.push({
          path: '/selectArea',
          query: {
            subActivityId: this.subActivityId,
            venueId: item.id,
          }
        })
      },
    }
  }
</script>

<style scoped>
 .iv-vence {
   width: 90%;
   margin: 5%;
   max-height: 228px;
 }
  .btn-venue {
    border-radius: 4px;
  }
</style>
