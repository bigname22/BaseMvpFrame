
<template>
  <div class="pull-to-refresh-page-app">
    <div class="pull-content">
      <ref-pull-con>
        <div v-for="i in players" class="list-item">
          {{ i }}
        </div>
      </ref-pull-con>
    </div>
  </div>
</template>
<style scoped>
  .list-item {
    height: 40px;
    line-height: 40px;
    border-bottom: 1px solid #ffffff;
    padding-left: 5px;
    width: 100%;
    background: #26a69a;
  }
</style>
<script>

  import RefPullCon from '../../widget/RefPullCon'

  export default {
    name: 'RefreshContainer',
    components: {
      RefPullCon
    },
    data(){
      return {
        players: ['kobe', 'fisher', 'jordan', 'shark', 'duncun']
      }
    },
    methods: {
      load(resolve){
        setTimeout(() => {
          for (let i = 0; i < 4; i++) {
            this.players.unshift('player No.' + Math.floor(Math.random() * 10) + 1);
          }
          resolve();
        }, 1000)
      }
    }
  }
</script>
