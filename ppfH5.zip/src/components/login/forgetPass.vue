<template>
    
</template>

<script>
    export default {
        name: "forgetPass"
    }
</script>

<style scoped>

</style>
