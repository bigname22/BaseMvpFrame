<template>
    
</template>

<script>
    export default {
        name: "register"
    }
</script>

<style scoped>

</style>
