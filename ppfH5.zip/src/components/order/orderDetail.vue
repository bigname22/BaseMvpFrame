<template>
    
</template>

<script>
    export default {
        name: "orderDetail"
    }
</script>

<style scoped>

</style>
