<template>
  <div class="hello">
    demo{{hand}}
    <v-touch
      class="ca"
      ref="panel"
      v-on:pinch="pinch"
      v-on:pinchstart="pinchStart"
      v-on:swipeleft="onSwipeLeft"
      v-on:pan="pan"
      v-on:panstart="panStart"
      v-on:tap="tap"
      style="background:black;width: 100%"
    >

      <div
        style=" width: 100%; height: 400px"
        :style="{transform:'translate(' + tranX + 'px,' + tranY + 'px) ' + 'scale('+panelScale+','+panelScale+')'}"
        ref="seat-box"
      >
        <div ref="seat-container" style="background: darkgoldenrod;" :style="{width: containerWidth + 'px',height: containerHeight + 'px'}"></div>
        <!--<div v-for="(item,index) in seats" style="margin: 4px; background: red;width: 20px; height: 20px" @click="btnClickItem(index)">-->
          <!--{{index}}-->
        <!--</div>-->
        <!--<div class="child"></div>-->
      </div>
    </v-touch>
  </div>
</template>

<script>
  import getData from "./mock.js"
  export default {
    name: 'HelloWorld',
    data() {
      return {
        seats: [],
        msg: 'Welcome to Your Vue.js App',
        hand: 'none',
        count: 0,
        panelScale: 1,
        lastPanelScale: 1,
        tranX: 0,
        tranY: 0,
        lastTranX: 0,
        lastTranY: 0,
        containerWidth: 0,
        containerHeight: 0,
      }
    },
    created () {
      // console.log(getData());
    },
    mounted () {
      debugger
      // this.insertElement(this.createElement(42, 12,'你',1),this.$refs['seat-box']);
      this.seats = JSON.parse(getData()).boothList;
      this.seats = this.seats.map(item => {
        return {
          X: item.X,
          Y: item.Y
        }
      });
      /* 实现思路
       * 步骤一：把整个座位图去掉多余的边界距离，即没有padding
       * 步骤二：利用绝对定位把座位按原本的位置描绘出来
       * 步骤三：进行缩放适应屏幕
        * */
      console.log('00============', this.seats);
      // ---------------------计算
      let boundaryInfo = {
        xMin: 0,     // x坐标最小值
        xMax: 0,     // x坐标最大值
        yMin: 0,     // y坐标最小值
        yMax: 0,     // y坐标最大值
        xDiff: 0,    // x坐标差  xMax - xMin
        yDiff: 0,    // y坐标差  yMax - yMin
        xMaxCount: 0,// x轴上最多数量
        yMaxCount: 0,// y轴上最多数量
        xScale: 1,   // 坐标与屏幕的缩放比例   windowWidth / xDiff
        yScale: 1,   // 坐标与屏幕的缩放比例   windowHeight / yDiff
        scale: 1,
        seatWidth: 20,// 座位宽度
        windowWidth: 0,// 屏幕宽
        windowHeight: 0,// 屏幕高
        boxWidth: 0,   // 容器宽
        boxHeight: 0,  // 容器高
      };
      // x最大值
      boundaryInfo.xMax = this.seats.reduce((a,b) => {
        return b.X > a.X ? b : a;
      }).X;
      // x最小值
      boundaryInfo.xMin = this.seats.reduce((a,b) => {
        return b.X > a.X ? a : b;
      }).X;
      // y最大值
      boundaryInfo.yMax = this.seats.reduce((a,b) => {
        return b.Y > a.Y ? b : a;
      }).Y;
      // y最小值
      boundaryInfo.yMin = this.seats.reduce((a,b) => {
        return b.Y > a.Y ? a : b;
      }).Y;
      boundaryInfo.xDiff = boundaryInfo.xMax - boundaryInfo.xMin;
      boundaryInfo.yDiff = boundaryInfo.yMax - boundaryInfo.yMin;
      let windowWidth = document.body.clientWidth;
      let windowHeight = document.body.clientHeight;
      console.log("3111111111111111", this.$refs['seat-box']);
      let boxWidth = this.$refs['seat-box'].offsetWidth;
      let boxHeight = this.$refs['seat-box'].offsetHeight;
      boundaryInfo.xScale = boxWidth / boundaryInfo.xDiff;
      boundaryInfo.yScale = boxHeight / boundaryInfo.yDiff;
      boundaryInfo.scale = Math.min(boundaryInfo.xScale, boundaryInfo.yScale);
      boundaryInfo.windowWidth = windowWidth;
      boundaryInfo.windowHeight = windowHeight;
      boundaryInfo.boxWidth = boxWidth;
      boundaryInfo.boxHeight = boxHeight;
        // --------------------处理逻辑
      // this.panelScale = Math.min(boundaryInfo.xScale, boundaryInfo.yScale);

      let newSeats = this.seats.map((item) => {
        item.X -= boundaryInfo.xMin;
        item.X *= boundaryInfo.scale;
        item.Y -= boundaryInfo.yMin;
        item.Y *= boundaryInfo.scale;
        return  item;
      });
      this.containerWidth = boundaryInfo.xDiff * boundaryInfo.scale + boundaryInfo.seatWidth;
      this.containerHeight = boundaryInfo.yDiff * boundaryInfo.scale  + boundaryInfo.seatWidth;
      console.log('^^============', boundaryInfo);
      console.log('^^============', newSeats);
      // let item = newSeats[60];
      // this.insertElement(this.createElement(item.X, item.Y,1,1),this.$refs['seat-box']);
      // let item1 = newSeats[2];
      // this.insertElement(this.createElement(item1.X, item1.Y,2,2),this.$refs['seat-box']);

      for(let i=0; i<newSeats.length; i++) {
        let item = newSeats[i];
        this.insertElement(this.createElement(item.X, item.Y,i,i),this.$refs['seat-container']);
      }
    },
    methods: {
      createElement (x,y,str,id) {
        let seatEl = document.createElement("div");
        seatEl.innerHTML = str;
        // seatEl.id = id;
        seatEl.style.cssText=`position: absolute;top: ${y}px;left: ${x}px;background: red;width: 20px;height: 20px;`;
        // div1.style.cssText="width:850px;height:500px;border:1px solid #000;";
        seatEl.onclick = () => {
          alert(str)
        }
        return seatEl;
      },
      insertElement (element, parent) {
        parent.appendChild(element);
      },
      btnClickItem (item) {
        alert(item)
      },
      pinch(e) {
        this.hand = '缩放' + this.count++;
        console.log('缩放', e.scale);
        console.log('缩放', this.$refs.panel.$el.style);
        this.panelScale = (e.scale - 1) + this.lastPanelScale;
        // this.$refs.panel.$el.style.WebkitTransform = "scale("+ e.scale +")";
        // this.$refs.panel.$el.style.MozTransform = "scale("+ e.scale +")";
        // this.$refs.panel.$el.style.msTransform = "scale("+ e.scale +")";
        // this.$refs.panel.$el.style.OTransform = "scale("+ e.scale +")";
        // this.$refs.panel.$el.style.transform = "scale("+ e.scale +")";
      },
      pinchStart(e) {
        this.lastPanelScale = this.panelScale;
      },
      onSwipeLeft(e) {
        this.hand = '左滑' + this.count++;
        console.log('左滑', e);
      },
      pan(e) {
        this.hand = 'pan' + this.count++;
        console.log('pan', e.deltaX + ',' + this.tranX);
        this.tranX = e.deltaX + this.lastTranX;
        this.tranY = e.deltaY + this.lastTranY;
      },
      panStart(e) {
        this.lastTranX = this.tranX;
        this.lastTranY = this.tranY;
      },
      tap(e) {
        this.hand = 'tap' + this.count++;
        console.log('tap', e);
      },
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
  .ca {
    /*transform: translate(0px, 0px) scale(0.5,0.5);*/
    border: 2px solid rebeccapurple;
  }
  .child {
    position: absolute;
    top: 42px;
    left: 12px;
    background: red;
    width: 20px;
    height: 20px;
  }
  .vc-switch {
    top: 78px !important;
    bottom: unset !important;
    right: unset !important;
    left: 0 !important;
  }
</style>
