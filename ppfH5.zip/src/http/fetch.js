/**
 * createBy: LiangSJ
 * date: 2019-3-5 15:00
 * desc: ??? API工具类
 */
import HttpService from './http.js'
import Constant from '../constant/constant'

let constant = new Constant();
let httpService = new HttpService();
class Fetch {
  httpService;
  TEST_URL = '';
  constructor() {
    this.httpService = httpService;
    // this.TEST_URL = constant.getBaseUrl();
  }

  /**
   * 核心方式：所有发起的api都会经过该入口;params如果有值的话会被拼接到url上，data是固定传给wx.request中的data字       * 段；所以一般params不用赋值，get/post都把参数给data就好了
   */
  _fetch = function (method = 'GET', url, param, data, isLoading, isAutoHideLoading) {
    method = method.toLocaleUpperCase();
    let resultPromise;
    if (method == 'POST') {
      resultPromise = this._fetchPost(url, param, data, isLoading, isAutoHideLoading);
    } else {
      resultPromise = this._fetchGet(url, param, data, isLoading, isAutoHideLoading);
    }
    return resultPromise;
  };

  _fetchGet = function (url, param, data, isLoading, isAutoHideLoading) {
    return this.httpService.getSimple(url, param, data, isLoading, isAutoHideLoading);
  };

  _fetchPost = function (url, param, data, isLoading, isAutoHideLoading) {
    return this.httpService.postSimple(url, param, data, isLoading, isAutoHideLoading);
  };

  // -------------API----------------



  /**
   * 获取我的信息
   */
  getMineInfo = () => {
    let param = {
     
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/User/GetUserInfo',
      null,
      param,
      true
    )
  };

  /**
   * 设置用户信息
   */
  setMineInfo = (name, gender, email, mobile, company) => {
    let param = {
      nickName: name,
      gender: gender,
      email: email,
      phone: mobile,
      companyName: company
    }
    return this._fetch(
      'POST',
      this.TEST_URL + '/User/SetUserInfo',
      null,
      param,
      true
    )
  };


  /**
   * 获取活动列表
   */
  getEventList = (pagePk, pageSize, pageIndex, searchText, startDate, endDate) => {
    let param = {
      pagePk: pagePk,
      pageSize: pageSize,
      pageIndex: pageIndex,
      searchText: searchText,
      startDate: startDate,
      endDate: endDate,
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Event/GetEventList',
      param,
      null,
      true
    )
  };

  /**
   * 获取活动详情
   */
  getEventDetail = (eventId) => {
    let param = {
      evtId: eventId
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Event/GetEvtDetail',
      null,
      param,
      true
    );
  };

  /**
   * 获取环节列表
   */
  getFuncList = (eventId) => {
    let param = {
      evtId: eventId,
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Event/GetFuncList',
      param,
      null,
      true
    )
  };

  /**
   * 获取环节详情
   */
  getFuncDetail = (funcId) => {
    let param = {
      funcId: funcId
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Event/GetFuncDetail',
      null,
      param,
      true
    );
  };

  /**
   * 获取场馆列表
   */
  getSectionList = (funcId) => {
    let param = {
      funcId: funcId
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Booth/GetExhibitionAreaList',
      param,
      null,
      true
    );
  };

  /**
   * 获取场馆的分区列表
   */
  getAreaList = (funcId, exhibitionAreaId) => {
    let param = {
      funcId: funcId,
      exhibitionAreaId: exhibitionAreaId
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Booth/GetAreaList',
      param,
      null,
      true
    );
  };

  /**
   * 获取场馆分区展位图（座位图）
   */
  getAreaBoothChart = (funcId, exhibitionAreaId, areaId) => {
    let param = {
      funcId: funcId,
      exhibitionAreaId: exhibitionAreaId,
      areaId: areaId
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Booth/GetAreaBoothChart',
      param,
      null,
      true
    );
  };

  /**
   * 预定座位
   */
  reserveSeats = (eventId, funcId, boothIdList) => {
    let param = {
      evtId: eventId,
      funcId: funcId,
      boothIdList: JSON.stringify(boothIdList)
    };
    return this._fetch(
      'POST',
      this.TEST_URL + '/Booth/BookBooth',
      null,
      param,
      true
    );
  };

  /**
   * 轮询订单状态
   */
  getQueueOrderStatus = (ordId) => {
    let param = {
      ordId: ordId
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Booth/GetQueueOrderStatus',
      null,
      param,
      false,
      true
    );
  };

  /**
   * 添加活动或环节至收藏夹
   */
  addToFav = (id, type, name, url) => {
    let param = {
      id: id,
      type: type,
      name: name,
      url: url
    };
    return this._fetch(
      'POST',
      this.TEST_URL + '/Event/AddToFav',
      param,
      null,
      true
    );
  };

  /**
   * 从收藏夹移除活动或环节
   */
  removeFav = (favId) => {
    let param = {
      favId: favId
    };
    return this._fetch(
      'POST',
      this.TEST_URL + '/Event/RemoveFav',
      param,
      null,
      true
    );
  };


  /**
   * 创建订单（创建订单->预支付->支付（这一步直接调用微信支付））
   */
  createOrder = function() {
    let param = {
      ordNumber: ordNumber,
      openid: openId
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/WX_XCX/GetCode2Session',
      null,
      param,
      true
    );
  };

  /**
   * 取消订单（）
  */
  cancelOrder = function (orderId, reason) {
    let param = {
      orderId: orderId,
      cancelReason: reason
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Order/CancelOrder',
      null,
      param,
      true
    );
  };

  /**
   * 创建订单（创建订单->预支付->支付（这一步直接调用微信支付））
   */
  queryOrderDetail = function (orderId) {
    let param = {
      orderId: orderId
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Order/GetOrderDetail',
      null,
      param,
      true
    );
  };

  /**
   * 查询订单列表
  */
  queryOrderList = function (searchText, sts , page, pageSize) {
    let param = {
      sts: sts,
      searchText: searchText,
      pageIndex: page,
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Order/GetOrderList',
      null,
      param,
      true
    );
  };

  /**
   * 预支付（创建订单->预支付->支付）
   */
  prePay = function(ordNumber, openId) {
    let param = {
      ordNumber: ordNumber,
      openid: openId
    };
    return this._fetch(
      'POST',
      this.TEST_URL + '/WX_PAY/WeChatPay',
      param,
      null,
      true
    );
  };

  /**
   * 封装预支付（erp）与支付的两个步骤
  */
  simplePay = function (orderNumber, openid, wxService){
    return new Promise((resolve, reject) => {
      this.prePay(orderNumber, openid).then(
        res => {
          if (res && res.statusCode == 200) {
            if (res.data && res.data.StatusCode == 200) {
              console.log('预支付成功', res);
              /**
               * {
                  "appId":"wx80efb22e99b88a8d",
                  "nonceStr":"bde5353b09244c51a8cc8a18cf8cc7f7",
                  "package":"prepay_id=wx15101726187433a82044ff211139981403",
                  "paySign":"70A9A7E372E64E7922EA5002A11E014B",
                  "signType":"MD5",
                  "timeStamp":"1547518646"
                  }
              */
              let prePayInfo = JSON.parse(res.data.Data);
              wxService.pay(prePayInfo.timeStamp, prePayInfo.nonceStr, prePayInfo.package, prePayInfo.signType, prePayInfo.paySign).then(
                res => {
                  resolve(res);
                  console.log('支付成功(可能取消之类的)---', res);
                }
              ).catch(
                err => {
                  console.log('支付失败---', res);
                  reject(res);
                }
              );
            } else {
              console.log('预支付失败，erp状态码异常', res);
              reject(res);
            }
          } else {
            console.log('预支付失败，wx状态码异常', res);
            reject(res);
          }
        }
      ).catch(
        err => {
          console.log('预支付失败', err);
          reject(err);
        }
      )
    })
  }

  /**
   * 上传分享用户 未完成(检测到打开的页面是其他用户分享过来的时候需要把发起分享的人传给后台做奖励处理)
   */
  uploadShareUser = function(shareUserId) {
    let param = {

    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/WX_XCX/GetCode2Session',
      null,
      param,
      true
    );
  };

  /**
   * 获取分享分裂产生列表
  */
  getShareOrderList = function (page, pageSize) {
    let param = {
      pageSize: pageSize,
      pageIndex: page
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/Order/GetShareOrderList',
      param,
      null,
      true
    );
  };

  /**
   * 查询收藏列表
   */
  queryCollections = function (param) {
    return this._fetch(
      'GET',
      this.TEST_URL + '/Event/GetFavList',
      null,
      param,
      true
    );
  };

  setUserInfo = function (unionId, nickName, gender, phone, openid, shareUnionId) {
    let param = {
      unionId: unionId,
      nickName: nickName,
      gender: gender,
      phone: phone,
      openid: openid,
      shareUnionId: shareUnionId
    };
    return this._fetch(
      'POST',
      this.TEST_URL + '/WX_XCX/SetUserInfo',
      null,
      param,
      true
    );
  };

  getConfig = function () {
    let param = {
    };
    return this._fetch(
      'GET',
      this.TEST_URL + '/PageConfig/GetConfig',
      null,
       param,
      false
    );
  }

}


export default Fetch;
