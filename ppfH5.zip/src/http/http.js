/**
 * createBy: LiangSJ
 * date: 2019-3-5 15:00
 * desc: ??? 网络请求工具类
 */

import StorageService from '../util/storage.js'
import Constant from '../constant/constant.js'
import axios from 'axios'

const constant = new Constant();
const storage = new StorageService();

class HttpService {
  BASE_URL = '';
  PAGE_PK = '';
  APP_KEY = '';

  constructor() {
    this.PAGE_PK = constant.getPagePk();
    this.BASE_URL = constant.getBaseUrl();
    this.APP_KEY = constant.getAppKey();
  }

  /**
   *  私有，核心请求：真正发起点
   *  @param: data是post/get请求都是传给data字段；param 如果有内容，则会追加到url中
   */
  _request = function(url, param, data, method, header) {
    if (param) {
      let paramsStr = this.addQueryString(param);
      url += '?' + paramsStr
    }
    // axios.defaults.headers.command
    return new Promise((resolve, reject) => {
      axios({
        method: method,
        url: url,
        data: data,
        headers: header
      }).then(res => {
        console.log('成功', res);
        resolve(res);
      }).catch(err => {
        console.log('错误', err);
        reject(err);
      });
    })
    //   wx.request({
    //     url: url,
    //     data: data,
    //     header: header,
    //     method: method,
    //     success: function(res) {
    //       resolve(res)
    //     },
    //     fail: function(res) {
    //       reject(res)
    //     },
    //     complete: function(res) {},
    //   })
    // })
  };

  addQueryString = function(params) {
    let paramsData = '';
    for (var key in params) {
      paramsData += key + '=' + params[key] + '&';
    }
    if(paramsData.endsWith('&')) {
      paramsData = paramsData.substr(0, paramsData.length - 1);
    }
    return paramsData;
  };

  /**
   * 带loading控制的请求
   */
  _requestWithLoading = function(url, param, data, method, header, isLoading, isAutoHideLoading) {
    url = this.BASE_URL + url;
    if (isLoading == null || typeof(isLoading) == 'undefined') {
      isLoading = true;
    }
    if (isLoading){

    }
    return new Promise((resolve, reject) => {
      this._request(url, param, data, method, header).then(res => {
        resolve(res);
        if (isAutoHideLoading == null || typeof (isAutoHideLoading) == 'undefined') {
          // wx.hideLoading()
        }
      }).catch(err => {
        reject(err);
        if (isAutoHideLoading == null || typeof (isAutoHideLoading) == 'undefined') {
          // wx.hideLoading()
        }
      })
    })
  };

  /**
   * post
   */
  post = function (url, param, data, header, isLoading, isAutoHideLoading) {
    return new Promise((resolve, reject) => {
      this._requestWithLoading(url, param, data, 'POST', header, isLoading, isAutoHideLoading).then(res => {
        resolve(res);
      }).catch(err => {
        reject(err);
      })
    })
  }

  /**
   * postSimple(适合程序大多数请求使用的)
   */
  postSimple = function(url, param, data, isLoading) {

    let header = {
      // 'content-type': 'application/x-www-form-urlencoded',
      "pagePk": this.PAGE_PK,
      token: storage.getToken(),
    };
    // let openid = this._initOpenid(param, data);
    // if (openid) {
    //   header.openid = openid;
    // }
    return new Promise((resolve, reject) => {
      this.post(url, param, data, header, isLoading).then(res => {
        resolve(res);
      }).catch(err => {
        reject(err);
      })
    });
  };

  /**
   * get
   */
  get = function (url, param, data, header, isLoading, isAutoHideLoading) {
    return new Promise((resolve, reject) => {
      this._requestWithLoading(url, param, data, 'GET', header, isLoading, isAutoHideLoading).then(res => {
        resolve(res);
      }).catch(err => {
        reject(err);
      })
    })
  };

  /**
   * getSimple(适合程序大多数请求使用的)
   */
  getSimple = function (url, param, data, isLoading, isAutoHideLoading) {
    let header = {
      // 'content-type': 'application/x-www-form-urlencoded',
      // 'content-type': 'application/json',
      pagePk: this.PAGE_PK,
      token: storage.getToken(),
    };
    // let openid = this._initOpenid(param, data);
    // if (openid) {
    //   header.openid = openid;
    // }
    return new Promise((resolve, reject) => {
      this.get(url, param, data, header, isLoading, isAutoHideLoading).then(res => {
        resolve(res);
      }).catch(err => {
        reject(err);
      })
    })
  };

}


export default HttpService;

